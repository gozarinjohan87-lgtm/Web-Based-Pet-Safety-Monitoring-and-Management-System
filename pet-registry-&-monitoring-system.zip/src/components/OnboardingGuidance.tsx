import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, BookOpen, Info, CheckCircle2, ShieldAlert } from 'lucide-react';

interface RoleOnboardingGuidanceProps {
  role: 'admin' | 'operator' | 'bite_center' | 'vet' | 'owner';
}

export default function RoleOnboardingGuidance({ role }: RoleOnboardingGuidanceProps) {
  const [isOpen, setIsOpen] = useState<boolean>(true);

  const getGuidanceData = () => {
    switch (role) {
      case 'admin':
        return {
          title: 'Municipal Admin Terminal Instructions',
          subtitle: 'Central Office & Veterinary Authority',
          color: 'border-amber-400 bg-amber-50/45',
          textClass: 'text-amber-950',
          bullets: [
            {
              title: 'Master Ledger & CRUD',
              desc: 'Review and manage pet records across all 20 Irosin barangays. Use the dynamic global search bar to locate records by keyword, owner name, or ID.'
            },
            {
              title: 'Pound Control & Adoptions',
              desc: 'Toggle the "Impounded" status of strays and authorize eligibility for the Public Adoption Board, adding profile bios for citizens to browse.'
            },
            {
              title: 'Analytical Tracking & Backups',
              desc: 'Monitor leash compliance rates, historical registration growth timelines, and perform a full JSON Database Snapshot backup for secure local records.'
            }
          ]
        };
      case 'operator':
        return {
          title: 'Barangay Operator Field Instructions',
          subtitle: 'Community Secretariat & Local Verification Hub',
          color: 'border-amber-400 bg-amber-50/45',
          textClass: 'text-amber-950',
          bullets: [
            {
              title: 'Pending Approvals Processing',
              desc: 'Review self-service registrations filed by residents in your barangay. Verify details physically in the field (house-to-house) or office to toggle status from "Pending" to "Active" so they can print collar QR codes.'
            },
            {
              title: 'Stray Sighting Mechanics',
              desc: 'Register unidentified roaming animals. If suspected to originate from adjacent neighborhoods, toggle "Suspected Neighboring Barangay Stray" to trigger an automated cross-boundary alert.'
            },
            {
              title: 'Offline Field Syncing',
              desc: 'Logging records during house-to-house rounds when disconnected? The background service worker stores data locally. Tap "Synchronize Now" once connectivity is restored.'
            }
          ]
        };
      case 'bite_center':
        return {
          title: 'Public Animal Bite Center Instructions',
          subtitle: 'Sterile Data Entry Portal & Quarantine Surveillance Ledger',
          color: 'border-amber-400 bg-amber-50/45',
          textClass: 'text-amber-950',
          bullets: [
            {
              title: 'Human Bite Case Logging',
              desc: 'Use the data-entry form to record patient age, gender, address, phone, and specific incident details (date, bite location, animal type, and associated Collar Pet ID if known).'
            },
            {
              title: 'Quarantine Pipeline Management',
              desc: 'Monitor biting animals throughout the observation phase. Transition quarantine state from "Pending Action" to "Under Quarantine" or "Case Closed" as health observation progresses.'
            },
            {
              title: 'Status History Timeline',
              desc: 'Every state change automatically logs a timeline record with clinical observation notes, forming an auditing trail accessible instantly below each case.'
            }
          ]
        };
      case 'vet':
        return {
          title: 'Private Vet Clinic Operator Instructions',
          subtitle: 'Clinical Log, Immunizations & Surgical Dossier Management',
          color: 'border-amber-400 bg-amber-50/45',
          textClass: 'text-amber-950',
          bullets: [
            {
              title: 'Instant QR Verification',
              desc: 'Utilize the smartphone or web camera QR Scanner to immediately resolve the digital collar tag of any animal brought to your clinic.'
            },
            {
              title: 'Immunization Updates',
              desc: 'Check the real-time vaccination shield state (Active vs Expired). Record booster shots directly to reset the 1-year automated rabies countdown alert.'
            },
            {
              title: 'Surgical Sterilization Records',
              desc: 'Update the spay or neuter status of animals, instantly archiving permanent surgical logs to prevent municipal-wide stray breeding.'
            },
            {
              title: 'Printable Medical Passports',
              desc: 'Generate a high-fidelity printable Veterinary Medical Passport PDF featuring immunization dates, spay details, and collar QR identification.'
            }
          ]
        };
      case 'owner':
        return {
          title: 'Pet Owner & Citizen Portal Instructions',
          subtitle: 'Irosin Animal Registry & Community Reporting Gate',
          color: 'border-amber-400 bg-amber-50/45',
          textClass: 'text-amber-950',
          bullets: [
            {
              title: 'Self-Service Pet Registration',
              desc: 'Register your dogs and cats, specifying visual traits, photos, and confinement setup (Leashed or Unleashed/Roaming). Newly added animals remain "Pending Verification" until certified by local BHWs.'
            },
            {
              title: 'Collar QR Identification Code',
              desc: 'Once your pet is verified, download their unique Collar QR code to attach to their tag. Anyone scanning this QR code can instantly see ownership details.'
            },
            {
              title: 'Immunization Booster Trackers',
              desc: 'Keep an eye on the color-coded vaccination countdown alerts. Green means the rabies shield is active; amber warns that immediate clinical booster shots are required.'
            },
            {
              title: 'Anonymous Sighting Reports',
              desc: 'Spotted a lost, loose, or aggressive stray roaming your barangay? Use the reporting portal to submit anonymous traits and locations to notify municipal operators.'
            }
          ]
        };
    }
  };

  const data = getGuidanceData();

  return (
    <div className={`border-2 ${data.color} rounded-2xl p-4 transition-all duration-300 relative shadow-xs`}>
      {/* Header Bar */}
      <div className="flex justify-between items-center cursor-pointer select-none" onClick={() => setIsOpen(!isOpen)}>
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-amber-500 text-white rounded-lg shadow-2xs shrink-0">
            <BookOpen className="h-4 w-4" />
          </div>
          <div>
            <h4 className={`font-display font-black text-xs sm:text-sm tracking-tight ${data.textClass}`}>
              {data.title}
            </h4>
            <p className="text-[10px] text-stone-500 font-bold uppercase tracking-wider">
              {data.subtitle}
            </p>
          </div>
        </div>
        
        <button className="text-stone-400 hover:text-stone-600 p-1 rounded-lg hover:bg-stone-100/50 transition-colors">
          {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
      </div>

      {/* Guidance Content with Tooltip Explanations */}
      {isOpen && (
        <div className="mt-4 pt-4 border-t border-stone-200/60 grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.bullets.map((bullet, idx) => (
            <div key={idx} className="bg-white/80 p-3 rounded-xl border border-stone-150/70 shadow-2xs relative group hover:border-amber-300 transition-all">
              <div className="absolute top-2.5 right-2.5 opacity-30 group-hover:opacity-100 transition-opacity">
                <HelpCircle className="h-3.5 w-3.5 text-amber-500 cursor-help" title={`Detailed instructions for ${bullet.title}`} />
              </div>

              <div className="flex items-center gap-1.5 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                <span className="font-bold text-[11px] text-stone-800 uppercase tracking-wide">
                  {bullet.title}
                </span>
              </div>
              <p className="text-[11px] text-stone-600 font-medium leading-relaxed">
                {bullet.desc}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
